#include "libreria_gz.h"
#include <stdio.h>
#include <ctype.h>


/*******************************************************/
/* main                                                */
/*******************************************************/
int main(int argc, char *argv[])
{

char *fasta=NULL;
char *qual=NULL;
char *extras=NULL;
int size=5000;
int res=0;

if (argc!=2)
{
  printf("Usage %s fbin_file\n\n",argv[0]);
  exit(-1);
}

initialize_sequential_reads(argv[1]);

char *sname=NULL;
while (read_data_sequential(&sname, &fasta, &qual, &extras)==0)
{
	printf ("***************************\n");
	printf ("RES of read_seq2 call is :%d, sname:%s\n",res,sname);
	if ( res==0 ) printf ("fasta:%s fasta size:%d\n",fasta,strlen(fasta));
	if ( res==0 ) printf ("qual:%s",qual);
	if (( res==0 )&& (extras!=NULL)) printf ("extras:%s\n",extras);
	if ( fasta!=NULL ) {free(fasta);fasta=NULL;}
	if ( qual!=NULL ) {free(qual);qual=NULL;}
	if ( extras!=NULL ) {free(extras);extras=NULL;}
}
close_sequential_reads();

return res;
}

