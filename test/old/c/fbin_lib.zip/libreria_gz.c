
#include <stdio.h>
#include <string.h>


#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#include <zlib.h>
#include <stdlib.h>

#define CHUNK 262144

// Maximum file name (including .idx)
#define MAXFNAME 512

// Maximum sequence name
#define MAXSEQNAME 1024
#define DEBUG 0

char dict_fasta[65536];
char dict_qual[65536];

struct sequence {
	char *name;
	long long pos_chunk_gz;
	long offset_init;       // offset del fasta dentro del chunkgz
	long fsize;
	long qsize;
	long esize;
	struct sequence *nextseq;
};

//struct sequence *seql=NULL;

static long long pos_chunk_gz=0;

static gzFile gzf_bin;
static int file_bin=0;
static gzFile gzf_index;
static char file_outname[10000];


int write_seq(char *seq_name, char *fasta, char *qual, char *extras)
{
	static counter=1;
	// compress data
	char metainfo[10000];	 
        int error=0;
        if (gzf_bin==NULL) {fprintf(stderr,"error with gzfile_bin, is NULL :%s\n",gzerror(gzf_bin,&error));return -2;}

	snprintf(metainfo,9950,"9999%s %d %d %d",seq_name,strlen(fasta),strlen(qual),strlen(extras)); 
	snprintf(metainfo,9970,"%4d%s %d %d %d",strlen(metainfo)-4,seq_name,strlen(fasta),strlen(qual),strlen(extras)); 
	long beginH=gztell(gzf_bin);
// TODO check gztell
        if (beginH==-1) {fprintf(stderr,"error with pos of beginH of gzfile_bin :%s\n",gzerror(gzf_bin,&error));return -2;}

	gzwrite(gzf_bin,metainfo,strlen(metainfo));
// TODO check gzwrite

	long beginI=gztell(gzf_bin);
        if (beginI==-1) {fprintf(stderr,"error with pos of beginI of gzfile :%s\n",gzerror(gzf_bin,&error));return -2;}
	int res=1;
	if (strlen(fasta)>0) res=gzwrite(gzf_bin,fasta,strlen(fasta)); //Z_FILTERED);
	if ( res==0 ) { fprintf(stderr,"Error when writting fasta\n");return -8;}
	long fastaS=gztell(gzf_bin)-beginI;
	if (strlen(qual)>0) res=gzwrite(gzf_bin,qual,strlen(qual)); //Z_FILTERED);
	if ( res==0 ) { fprintf(stderr,"Error when writting qual\n");return -8;}
	long qualS=gztell(gzf_bin)-fastaS-beginI;
	if (strlen(extras)>0) res=gzwrite(gzf_bin,extras,strlen(extras)); //Z_FILTERED);
	if ( res==0 ) { fprintf(stderr,"Error when writting extras\n");return -8;}
	long extrasS=gztell(gzf_bin)-qualS-fastaS-beginI;
	if (DEBUG) printf("string %s, size %d\n",fasta,strlen(fasta));
	//	add_sequence(&seql,seq_name,pos_chunk_gz,beginI,fastaS,qualS,extrasS);

	// Write index file 
	char tmp[10000];
	sprintf(tmp,"%s %lld %ld\n",seq_name,pos_chunk_gz,beginH);
	if ( DEBUG ) printf("%s",tmp);
	gzwrite(gzf_index,tmp,strlen(tmp));

	counter++;
//	if (counter > 2) fprintf(stderr,"Probando static counter para llamadas desde ruby, valor %d\n",counter);

// create new chunk
        if ((counter%10000)==0) {
		gzclose (gzf_bin);
		file_bin=open (file_outname,O_APPEND);
		long long pos=lseek(file_bin,0,SEEK_END);
		if (pos==-1)  {fprintf(stderr,"error %d seeking file :%s\n",errno,strerror(errno));return -1;}
		pos_chunk_gz=pos;
		close(file_bin);
		gzf_bin=gzopen (file_outname,"ab");
		if (gzf_bin==NULL) {fprintf(stderr,"error opening gzfile :%s\n",gzerror(gzf_bin,&error));return -2;}
	}
	return 0;
}



/* Reads the metadata from the main file 
   It initializes the version variable 
*/
int read_bin_file_metadata()
{

}

/* Reads the metadata from the index file 
   It initializes the version and binary_search variable 
*/
int read_index_file_metadata()
{

}

/* reads the header of a sequence in the main file.
   the pointer to the file points to the fasta data after calling read_seq_header 
   returns 0 if ok
 	-1 if there is an error
	-2 if EOF
*/

int read_seq_header(gzFile gzf_bin,char *seq_name,int *fastaS, int *qualS, int*extrasS)
{
  int header_size=4;
  char hsize[40];
  char tmp[1000];
  char sname[10000];
  long pos=gzread(gzf_bin,hsize,header_size);
  if ( pos==0 ) return -2;
  if ( pos==-1 ) {fprintf(stderr,"error reading header\n");return -1;}
  sscanf(hsize,"%d",&header_size);
  pos=gzread(gzf_bin,tmp,header_size);
  if ( pos==0 ) return -2;
  if ( pos==-1 ) {fprintf(stderr,"error reading header\n");return -1;}
  tmp[header_size]=0;
//  printf("HEADER:%s\n",tmp);
  int reads=sscanf(tmp,"%s %d %d %d",sname,fastaS,qualS,extrasS); 
  if (reads!=4) {return -1;};
  if (seq_name!=NULL) strncpy(seq_name,sname,10000);
  return 0;
}

static file_version=0;
static binary_search=0;  // false

// check files before reading
// it initializes the previous variables, file_version and binary_search
// result :
// 0 : if both the bin and index files exists and are from the current version
// 1 : if both the bin and index files exists but are from another version
// 2 : if both files are missing
// 3 : if bin file is missing
// 4 : if index file is missing
int check_files()
{
  
// open the files, read and check the header
  return 0;
}

// returns the version of the opened file
int version()
{
  if (gzf_bin==NULL) return -1;
  return file_version;
}

/* 
mode can be:
1 - random, for each read it begins to read from the beggining of index
2 - sequential, it keeps the position inside the index and main files.
*/
int initialize_sequential_reads(char *filename)
{
        char header[10000];
  	int fastaS,qualS,extrasS=0;
	gzf_bin=gzopen (filename,"r");
// reads the metadata
	int res=read_seq_header(gzf_bin,header, &fastaS, &qualS, &extrasS);
	if ( strlen(header)<19 ) {fprintf(stderr,"Header incorrect:%s\n",header);return -1;}
        header[strlen(header)-2]=0;
        if (strncmp(header,"UMACOMPRESSEDFORMAT",20)!=0) return -1;
	return 0;
}

int read_data_sequential(char **seq_name, char **fasta, char **qual, char **extras)
{
  int res=0;
  int error=0;
  int fastaS,qualS,extrasS=0;

  int bufsize=150000;
  if ( *seq_name == NULL ) {*seq_name=(char *)malloc(10000);strncpy(*seq_name,"",4);}
  res=read_seq_header(gzf_bin, *seq_name, &fastaS, &qualS, &extrasS);
  if (res==-2) // EOF
	return -9;
  if ( *fasta  == NULL )  {*fasta=(char *)malloc(fastaS+1);strncpy(*fasta,"",fastaS);}
  if ( *qual == NULL) {*qual=(char *)malloc(qualS+1);strncpy(*qual,"",qualS);}
  if (( *extras == NULL )&&(extrasS>0)) {*extras=(char *)malloc(extrasS+1);strncpy(*extras,"",extrasS);}

  long pos=gzread(gzf_bin,*fasta,fastaS);
  (*fasta)[fastaS]=0;
  if ( DEBUG ) printf(" read from pos %d %s fasta %d\n",pos,*fasta,fastaS);
  pos=gzread(gzf_bin,*qual,qualS);
  (*qual)[qualS]=0;
  if ( DEBUG ) printf(" read from pos %d %s qual %d \n",pos,*qual,qualS);
  if (extrasS>0) {pos=gzread(gzf_bin,*extras,extrasS);(*extras)[extrasS]=0;}
  if ( DEBUG ) printf(" read from pos %d extra %d\n",pos,extrasS);
  return 0;

}
int close_sequential_reads()
{
  gzclose(gzf_bin);
}

/* 
   read_seq reads from filename the sequence named seq_name and returns its
	fasta, qual and extras in those variables.
   It returns 0 if there are no errors, otherwise it returns:
   -2 : error opening index file (it doesn't exists)
   -3 : error reading index file
   -4 : error sequence not found in index file
   -5 : error opening file (it doesn't exists)
   -6 : error reading file 
   -7 : error sequence not found
   -8 : error uncompressing sequence
   -9 : EOF

*/

int read_seq(char *filename, char *seq_name, char **fasta, char **qual, char **extras)
{
/* Hacer grep en filename.index de seq_name */
/* Una vez encontrado leer su info (indice y offsets) */
/* leer de filename en sus offests el fasta qual y extras */
/* Descomprimirlo y devolverlo */

  char indexname[MAXFNAME];
  char sname[MAXSEQNAME];// sequence name
  char *fasta_comp;      // compressed fasta
  char *qual_comp;     // compressed qual
  char *extras_comp;     // compressed extras
  long long beginH,gz_chunk=0;
  int fastaS,qualS,extrasS=0;
  char tmp[10000];
  int res=0;
  int error=0;

  int bufsize=150000;
  if ( *fasta  == NULL )  {*fasta=(char *)malloc(bufsize);strncpy(*fasta,"",bufsize);}
  if ( *qual == NULL) {*qual=(char *)malloc(bufsize);strncpy(*qual,"",bufsize);}
  if ( *extras == NULL ) {*extras=(char *)malloc(bufsize);strncpy(*extras,"",bufsize);}
  snprintf(indexname,MAXFNAME,"%s.index",filename);

  if ( DEBUG ) printf(" indexname: %s, seq: %s\n",indexname,seq_name);
  //FILE * filein=fopen(indexname,"r");
  gzFile gzfile_index=gzopen(indexname,"r");
  if (gzfile_index==NULL) {
	fprintf(stderr,"error opening gzfile_index :%s\n",gzerror(gzfile_index,&error));
	return -2;
  }

  // Reads the index to this info, and the offset to its data
  int reads=3;
  while ( reads == 3 ) {
        gzgets(gzfile_index,tmp,sizeof(tmp));
	reads=sscanf(tmp,"%s %lld %lld",sname,&gz_chunk,&beginH);
  	if ( DEBUG ) printf("line read %d from index file: %s, %d,  %d\n",reads,sname,gz_chunk,beginH);
	if (( reads != 3 ) && ( reads!=EOF )) {
		fprintf(stderr,"Error scanning index: %d\n",reads);
		gzclose(gzfile_index);
		return -3;
	}
        if ( strncmp(sname, seq_name,MAXSEQNAME)==0) reads=999; // to get out, seq found
  }
  gzclose(gzfile_index);
  if (reads==EOF) {fprintf(stderr,"Sequence not found\n");return -4;}
printf("SEQUENCE FOUND\n");
  
  if ( DEBUG ) printf(" read %d from index file: %s, %ld,  %ld\n",reads,sname,gz_chunk,beginH);
  int dataf=open(filename, O_RDONLY);
  res=lseek(dataf,gz_chunk,SEEK_SET);
// TODO check res
  gzFile gzfile_bin=gzdopen (dataf,"r");
  
  res=gzseek(gzfile_bin,beginH,SEEK_SET);
// TODO check res

  if ( DEBUG ) printf(" lseek %d\n",res);
//  fasta=malloc(fastaO+1);
//  qual=malloc(qualO+1);
//  extras=malloc(extrasO+1);
//  long pos=gzread(gzfile_bin,header,4); 
// read sequence header 
  res=read_seq_header(gzfile_bin,NULL, &fastaS, &qualS, &extrasS);
  long pos=gzread(gzfile_bin,*fasta,fastaS); 
  fasta[fastaS]=0;
  if ( DEBUG ) printf(" read from pos %d %s fasta %d\n",pos,*fasta,fastaS);
  pos=gzread(gzfile_bin,*qual,qualS); 
  qual[qualS]=0;
  if ( DEBUG ) printf(" read from pos %d %s qual %d \n",pos,*qual,qualS);
  if (extrasS>0) {pos=gzread(gzfile_bin,*extras,extrasS); extras[extrasS]=0;}
  if ( DEBUG ) printf(" read from pos %d extra %d\n",pos,extrasS);
  gzclose(gzfile_bin);
  
  return 0;
}


// initialize the state for doing writes
// two modes:
// 1 .- new files
// 2 .- add data to files, if they don't exist they are created
int initialize_writes(char *output_name, int mode)
{

// check if the files exists, in case it exists check if it has the
// correct metadata and if it is of the correct version
// in other case exits with an error

	int state=check_files(output_name);
	if (state==1) {
		fprintf(stderr,"File is from a different version\n");
		return -1;
	}
	if ((state!=2)&&(state!=0)) {
		fprintf(stderr,"Error %d when checking files\n",state);
		return -1;
	}
	// copy the name of the file

	strncpy(file_outname,output_name,10000);
	// open the compressed files
	int error=0;
	int flags=O_WRONLY|O_CREAT|O_TRUNC;
	if (mode==2) flags=O_RDWR;
printf("mode:%d\n",mode);
	char indexname[MAXFNAME];
	snprintf(indexname,MAXFNAME,"%s.index",output_name);
	int file_index=open(indexname,flags,0644);
	if (file_index==-1) return -2;
	file_bin=open(output_name,flags,0644);
	printf("fd:%d\n",file_bin);
	if (file_bin==-1) {fprintf(stderr,"error opening file_bin for writting:%s\n",strerror(errno));return -2;}
	if (mode==2) {
		long long pos=lseek(file_index,0,SEEK_END);
 		if (pos==-1) {fprintf(stderr,"error going to end of index file %s\n",strerror(errno)); return -2;}
		pos=lseek(file_bin,0,SEEK_END);
 		if (pos==-1) {fprintf(stderr,"error going to end of bin file %s\n",strerror(errno)); return -2;}
                pos_chunk_gz=pos;
	}
	gzf_index=gzdopen(file_index,"w");
	if (gzf_index==NULL) {
		fprintf(stderr,"error opening gzfile_index for writting:%s\n",gzerror(gzf_index,&error));
		return -2;
	}
	gzf_bin=gzdopen (file_bin,"w");
	if (gzf_bin==NULL) {
		fprintf(stderr,"error opening gzfile for writting:%s\n",gzerror(gzf_bin,&error));
		return -2;
	}

	// initializes the files, writting the metadata
 	if (mode==1) {
	        char header[100];
		sprintf(header,"  28UMACOMPRESSEDFORMAT_1 0 0 0\n");
		int res=gzwrite(gzf_bin,header,strlen(header));
		sprintf(header,"UMACOMPRESSEDFORMAT 1 0 999999999999 999999999999\n");
		res=gzwrite(gzf_index,header,strlen(header));
	}
	return 0;
}



int closes_writes()
{
        gzclose(gzf_bin);
        gzclose(gzf_index);
}


struct sequence *search_seq(struct sequence *seq_list,char *name )
{
  struct sequence *current=seq_list;
  while ((current!=NULL) && ( strcmp(current->name,name)!=0)) {
	  current=current->nextseq;
  }
  return current;
}

int add_sequence(struct sequence **seq_list,char *name, long long pos_chunk_gz, long offset_init,long fsize,long qsize,long esize)
{
  struct sequence *current=NULL;// =search_seq(*seq_list,name);
  // ponerlo el primero.
  if (current==NULL) {
	  current=malloc(sizeof(struct sequence));
	  current->nextseq=*seq_list;
	  *seq_list=current;
	  if (name!=NULL) {
		  current->name=malloc(sizeof(name));
		  strncpy(current->name,name,sizeof(name));
	  } else current->name=NULL;
  }
  current->pos_chunk_gz=pos_chunk_gz;
  current->offset_init=offset_init;
  current->fsize=fsize;
  current->qsize=qsize;
  current->esize=esize;
  return 0;
}

int add_info_to_sequence(struct sequence **seq_list,char *name, long long pos_chunk_gz,long offset_init,long fsize,long qsize,long esize)
{
	struct sequence *current=search_seq(*seq_list,name);
	// ponerlo el primero.
	if (current==NULL) {
		current=malloc(sizeof(struct sequence));
		current->nextseq=*seq_list;
		*seq_list=current;
		if (name!=NULL) {
			current->name=malloc(sizeof(name));
			strncpy(current->name,name,sizeof(name));
		} else current->name=NULL;
	}
	current->pos_chunk_gz=pos_chunk_gz;
	current->offset_init=offset_init;
	current->fsize=fsize;
	current->qsize=qsize;
	current->esize=esize;
	return 0;
}

int print_seqs(struct sequence *seq_list)
{
printf("imprime lista de secuencias:\n");
struct sequence *current=seq_list;
int i=0;
	while ( current!=NULL ) {
		printf("seqname:%s pos_chunk:%d offset_init:%d fsize:%d qsize:%d esize:%d\n",current->name,current->pos_chunk_gz,current->offset_init,current->fsize,current->qsize,current->esize);
		current=current->nextseq;
	}
	

}

int process_biofile(char *fname, char *qfname, char *efname, char *outname)
{

	char sname[MAXSEQNAME];// sequence name
	char qname[MAXSEQNAME];// sequence name
	char next_sname[MAXSEQNAME];// sequence name
	char next_qname[MAXSEQNAME];// sequence name

	char fasta[150000];
	char qual[150000];
	char next_fcomment[150000];
	char next_qcomment[150000];
	char tmp[150000];
	
	int cnt=1;

	// Open fasta and qual files
        FILE *file_fasta=fopen(fname,"r");
	if (file_fasta==NULL) { fprintf(stderr,"error opening fasta file %s, result %d %s\n",fname,errno,strerror(errno));return -2;};
//	setvbuf(file_fasta,NULL,_IONBF,0);
        FILE *file_qual=fopen(qfname,"r");
  	if (file_qual==NULL) { fprintf(stderr,"error opening qual file %s, result %d %s\n",qfname,errno,strerror(errno));return -2;};
//	setvbuf(file_qual,NULL,_IONBF,0);
	int error=0;
	int end=0;  //0 is false

	// reads the name of the sequence from both
	
	fscanf(file_qual,">%9000s",qname);
	fscanf(file_fasta,">%9000s",sname);
	printf("file:%s q:%s seqname:%s qseqname%s\n",fname, qname,sname,qname);
	char *res;

	error=initialize_writes(outname,1);

	sprintf(next_fcomment,"");
	sprintf(next_qcomment,"");

	while (!end) {
		if ( strcmp(sname,qname)!=0 ) {error = -9; goto end;}
		// load the qual and fasta

		sprintf(fasta,"");
		sprintf(fasta,"%s",next_fcomment);
		sprintf(next_fcomment,"");
		sprintf(tmp,"");
		res=fasta;
		while (( res!=NULL ) && (tmp[0]!='>' )) {
			res=fgets(tmp,150000,file_fasta);
if ( DEBUG ) printf(" ***** Tras lee fasta : %s\n tmp:%s, end: %d tmp1:%c %c\n",sname,tmp,end,tmp[0],tmp[1]);

			if ((tmp[0]!='>')&&(res!=NULL)) sprintf (fasta,"%s%s",fasta,tmp);
			else if (res!=NULL) {sscanf(tmp,">%9000s",next_sname); strncpy(next_fcomment,tmp+strlen(next_sname)+2,sizeof(next_fcomment));}
if ( DEBUG ) printf(" int lee fasta : %s\n fasta:%s, next_sname: %s tmp1:%c %c\n",sname,fasta,next_sname,tmp[0],tmp[1]);
		}
		if (res==NULL) end=1;
		
		sprintf(qual,"");
		sprintf(qual,"%s",next_qcomment);
		sprintf(next_qcomment,"");
		res=qual;
		sprintf(tmp,"");
		while (( res!=NULL ) && (tmp[0]!='>' )) {
			res=fgets(tmp,150000,file_qual);
			if ((tmp[0]!='>')&&(res!=NULL)) sprintf (qual,"%s%s",qual,tmp);
			else if (res!=NULL) {sscanf(tmp,">%9000s",next_qname); strncpy(next_qcomment,tmp+strlen(next_qname)+2,sizeof(next_qcomment));}
		}
		if (res==NULL) end=1;
		int error_wr=write_seq(sname, fasta,qual,"");
		if (error_wr!=0)  { end=1;error=error_wr; };
		if (error_wr==0)  cnt++;
		if ( DEBUG ) printf(" seq leida %s\n fasta:%s, qual: %s end: %d\n",sname,fasta,qual,end);
		if ( DEBUG ) printf("-------- To the next one: seq leida fas %s, qual: %s end:%d\n",sname,qname,end);
		strcpy(sname,next_sname);
		strcpy(qname,next_qname);

	}

// repeat until EOF or error
  end:
	fclose(file_fasta);
	fclose(file_qual);
	closes_writes();
	//fclose(file_index);
//		print_seqs(seql);
	return error;
}

int init_dicts(char *d_fasta,char *d_qual,int size)
{
	char *dict_f="fasta.dic";
	char *dict_q="qual.dic";
        FILE *f_d_fasta=fopen(dict_f,"r");
	if (f_d_fasta==NULL) { fprintf(stderr,"error opening qual file %s, result %d %s\n",dict_f,errno,strerror(errno));return -2;};
	fread(d_fasta,size,1,f_d_fasta);
	fclose(f_d_fasta);

        FILE *f_d_qual=fopen(dict_q,"r");
	if (f_d_qual==NULL) { fprintf(stderr,"error opening qual file %s, result %d %s\n",dict_q,errno,strerror(errno));return -2;};
	fread(d_qual,size,1,f_d_fasta);
	fclose(f_d_qual);
}




