#include "libreria_gz.h"
#include <stdio.h>
#include <ctype.h>


/*******************************************************/
/* main                                                */
/*******************************************************/
int main(int argc, char *argv[])
{
  // check params
  if (argc!=4)
  {
    printf("Usage %s fasta_file qual_file output_file\n\n",argv[0]);
    exit(-1);
  }
 
  // process file
  int res=process_biofile(argv[1],argv[2],argv[2],argv[3]);

  return res;
}

