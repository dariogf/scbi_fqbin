#include "libreria_gz.h"
#include <stdio.h>
#include <ctype.h>


/*******************************************************/
/* main                                                */
/*******************************************************/
int main(int argc, char *argv[])
{

char *fasta=NULL;
char *qual=NULL;
char *extras=NULL;
int size=5000;
int res=0;

if (argc!=3)
{
  printf("Usage %s fbin_file seq_name\n\n",argv[0]);
  exit(-1);
}
 


res=read_seq(argv[1],argv[2], &fasta, &qual, &extras);
//res=read_seq("prueba2gz.fbin","F143CJN01EN6AH", &fasta, &qual, &extras);
printf ("-------------------------------------------------------------\n");
printf ("RES of read_seq2 call is :%d\n",res);
if ( res==0 ) printf ("fasta:%s\n fasta size:%d\n",fasta,strlen(fasta));
if ( res==0 ) printf ("qual:%s\n",qual);
if (( res==0 )&& (extras!=NULL)) printf ("extras:%s\n",extras);
if ( fasta!=NULL ) {free(fasta);fasta=NULL;}
if ( qual!=NULL ) {free(qual);qual=NULL;}
if ( extras!=NULL ) {free(extras);extras=NULL;}

return res;
}

